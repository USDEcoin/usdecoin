Building Usdecoin
================

See doc/build-*.md for instructions on building the various
elements of the Usdecoin Core reference implementation of Usdecoin.
