Sample configuration files for:
```
SystemD: usdecoind.service
Upstart: usdecoind.conf
OpenRC:  usdecoind.openrc
         usdecoind.openrcconf
CentOS:  usdecoind.init
macOS:    org.usdecoin.usdecoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
